window.__require = function t(e, n, r) {
function a(o, i) {
if (!n[o]) {
if (!e[o]) {
var c = o.split("/");
c = c[c.length - 1];
if (!e[c]) {
var l = "function" == typeof __require && __require;
if (!i && l) return l(c, !0);
if (s) return s(c, !0);
throw new Error("Cannot find module '" + o + "'");
}
o = c;
}
var u = n[o] = {
exports: {}
};
e[o][0].call(u.exports, function(t) {
return a(e[o][1][t] || t);
}, u, u.exports, t, e, n, r);
}
return n[o].exports;
}
for (var s = "function" == typeof __require && __require, o = 0; o < r.length; o++) a(r[o]);
return a;
}({
LoadGameController: [ function(t, e, n) {
"use strict";
cc._RF.push(e, "89e3bULnINAO5LStk1zefH7", "LoadGameController");
var r, a = this && this.__extends || (r = function(t, e) {
return (r = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
})(t, e);
}, function(t, e) {
r(t, e);
function n() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (n.prototype = e.prototype, new n());
}), s = this && this.__decorate || function(t, e, n, r) {
var a, s = arguments.length, o = s < 3 ? e : null === r ? r = Object.getOwnPropertyDescriptor(e, n) : r;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) o = Reflect.decorate(t, e, n, r); else for (var i = t.length - 1; i >= 0; i--) (a = t[i]) && (o = (s < 3 ? a(o) : s > 3 ? a(e, n, o) : a(e, n)) || o);
return s > 3 && o && Object.defineProperty(e, n, o), o;
}, o = this && this.__awaiter || function(t, e, n, r) {
return new (n || (n = Promise))(function(a, s) {
function o(t) {
try {
c(r.next(t));
} catch (t) {
s(t);
}
}
function i(t) {
try {
c(r.throw(t));
} catch (t) {
s(t);
}
}
function c(t) {
t.done ? a(t.value) : (e = t.value, e instanceof n ? e : new n(function(t) {
t(e);
})).then(o, i);
var e;
}
c((r = r.apply(t, e || [])).next());
});
}, i = this && this.__generator || function(t, e) {
var n, r, a, s, o = {
label: 0,
sent: function() {
if (1 & a[0]) throw a[1];
return a[1];
},
trys: [],
ops: []
};
return s = {
next: i(0),
throw: i(1),
return: i(2)
}, "function" == typeof Symbol && (s[Symbol.iterator] = function() {
return this;
}), s;
function i(t) {
return function(e) {
return c([ t, e ]);
};
}
function c(s) {
if (n) throw new TypeError("Generator is already executing.");
for (;o; ) try {
if (n = 1, r && (a = 2 & s[0] ? r.return : s[0] ? r.throw || ((a = r.return) && a.call(r), 
0) : r.next) && !(a = a.call(r, s[1])).done) return a;
(r = 0, a) && (s = [ 2 & s[0], a.value ]);
switch (s[0]) {
case 0:
case 1:
a = s;
break;

case 4:
o.label++;
return {
value: s[1],
done: !1
};

case 5:
o.label++;
r = s[1];
s = [ 0 ];
continue;

case 7:
s = o.ops.pop();
o.trys.pop();
continue;

default:
if (!(a = o.trys, a = a.length > 0 && a[a.length - 1]) && (6 === s[0] || 2 === s[0])) {
o = 0;
continue;
}
if (3 === s[0] && (!a || s[1] > a[0] && s[1] < a[3])) {
o.label = s[1];
break;
}
if (6 === s[0] && o.label < a[1]) {
o.label = a[1];
a = s;
break;
}
if (a && o.label < a[2]) {
o.label = a[2];
o.ops.push(s);
break;
}
a[2] && o.ops.pop();
o.trys.pop();
continue;
}
s = e.call(t, o);
} catch (t) {
s = [ 6, t ];
r = 0;
} finally {
n = a = 0;
}
if (5 & s[0]) throw s[1];
return {
value: s[0] ? s[1] : void 0,
done: !0
};
}
};
Object.defineProperty(n, "__esModule", {
value: !0
});
var c = cc._decorator, l = c.ccclass, u = c.property;
function p(t, e) {
for (var n = t.split("."), r = e.split("."), a = 0; a < n.length; ++a) {
var s = parseInt(n[a]), o = parseInt(r[a] || "0");
if (s !== o) return s - o;
}
return r.length > n.length ? -1 : 0;
}
var f = function(t) {
a(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.loadingSprite = null;
e.loadingLabel = null;
e._updating = !1;
e._canRetry = !1;
e._storagePath = "";
e.stringHost = "";
e._am = null;
e._checkListener = null;
e._updateListener = null;
e.count = 0;
return e;
}
e.prototype.onLoad = function() {
if (jsb) {
this._storagePath = (jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "/") + "remote-assets";
this._am = new jsb.AssetsManager("", this._storagePath, p);
this._am.setVerifyCallback(function(t, e) {
var n = e.compressed, r = e.md5, a = e.path;
e.size;
if (n) {
cc.log("Verification passed : " + a);
return !0;
}
cc.log("Verification passed : " + a + " (" + r + ")");
return !0;
});
}
};
e.prototype.onDestroy = function() {
if (this._updateListener) {
this._am.setEventCallback(null);
this._updateListener = null;
}
};
e.prototype.start = function() {
return o(this, void 0, void 0, function() {
var t;
return i(this, function() {
t = this;
cc.sys.isMobile && this.fetchData("https://firebasestorage.googleapis.com/v0/b/film-388915.appspot.com/o/jsonSoiReal.json?alt=media&token=b65f713d-00ce-4079-b9bf-5d417f2cc9d2").then(function(e) {
console.log("Parsed JSON data:", e);
console.log(e.HOTUPDATE);
t.onCheckGame(e.HOTUPDATE);
t.scheduleNext();
}).catch(function(t) {
console.error("Error fetching data:", t);
});
return [ 2 ];
});
});
};
e.prototype.scheduleNext = function() {
var t = this;
this.schedule(function() {
t.count += .01;
t.updateProcess(t.count);
t.count >= 1 && t.loadMyGame();
}, .03);
};
e.prototype.fetchData = function(t) {
return new Promise(function(e, n) {
var r = new XMLHttpRequest();
r.open("GET", t, !0);
r.onreadystatechange = function() {
if (4 === r.readyState) if (200 === r.status) try {
var t = JSON.parse(r.responseText);
e(t);
} catch (t) {
n(t);
} else n(new Error("HTTP error! status: " + r.status));
};
r.send();
});
};
e.prototype.loadMyGame = function() {
this.unscheduleAllCallbacks();
cc.director.loadScene("HomeScene");
};
e.prototype.onCheckGame = function(t) {
this.unscheduleAllCallbacks();
this.stringHost = t;
this.hotUpdate();
};
e.prototype.loadCustomManifest = function(t) {
var e, n = new jsb.Manifest((e = t, JSON.stringify({
packageUrl: e + "/",
remoteManifestUrl: e + "/project.manifest",
remoteVersionUrl: e + "/version.manifest",
version: "0.0.0",
assets: {},
searchPaths: []
})), this._storagePath);
this._am.loadLocalManifest(n, this._storagePath);
};
e.prototype.updateCb = function(t) {
var e = !1, n = !1;
switch (t.getEventCode()) {
case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
cc.log("No local manifest file found, hot update skipped.");
n = !0;
break;

case jsb.EventAssetsManager.UPDATE_PROGRESSION:
t.getDownloadedFiles(), t.getTotalFiles(), t.getMessage();
this.updateProcess(t.getPercent());
break;

case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
cc.log("Fail to download manifest file, hot update skipped.");
n = !0;
break;

case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
cc.log("Already up to date with the latest remote version.");
e = !0;
break;

case jsb.EventAssetsManager.UPDATE_FINISHED:
cc.log("Update finished. " + t.getMessage());
e = !0;
break;

case jsb.EventAssetsManager.UPDATE_FAILED:
cc.log("Update failed. " + t.getMessage());
this._updating = !1;
this._canRetry = !0;
n = !0;
break;

case jsb.EventAssetsManager.ERROR_UPDATING:
cc.log("Asset update error: " + t.getAssetId() + ", " + t.getMessage());
n = !0;
break;

case jsb.EventAssetsManager.ERROR_DECOMPRESS:
cc.log(t.getMessage());
n = !0;
}
if (n) {
this._am.setEventCallback(null);
this._updateListener = null;
this._updating = !1;
this.loadMyGame();
}
if (e) {
this._am.setEventCallback(null);
this._updateListener = null;
var r = jsb.fileUtils.getSearchPaths(), a = this._am.getLocalManifest().getSearchPaths();
Array.prototype.unshift.apply(r, a);
cc.sys.localStorage.setItem("HotUpdateSearchPaths-game", JSON.stringify(r));
jsb.fileUtils.setSearchPaths(r);
setTimeout(function() {
cc.game.restart();
}, 500);
}
};
e.prototype.hotUpdate = function() {
if (this._am && !this._updating) {
this._am.setEventCallback(this.updateCb.bind(this));
this.loadCustomManifest(this.stringHost);
this._am.update();
this._updating = !0;
}
};
e.prototype.updateProcess = function(t) {
cc.log("Updated file: " + t);
this.loadingSprite.fillRange = t;
this.loadingLabel.string = "Đang cập nhật dữ liệu mới từ máy chủ " + Math.round(100 * t) + "%";
};
s([ u(cc.Sprite) ], e.prototype, "loadingSprite", void 0);
s([ u(cc.Label) ], e.prototype, "loadingLabel", void 0);
return s([ l ], e);
}(cc.Component);
n.default = f;
cc._RF.pop();
}, {} ],
use_reversed_rotateBy: [ function(t, e) {
"use strict";
cc._RF.push(e, "fc304fMEsdGnb9I6pzgZ46c", "use_reversed_rotateBy");
cc.RotateBy._reverse = !0;
cc._RF.pop();
}, {} ]
}, {}, [ "LoadGameController", "use_reversed_rotateBy" ]);